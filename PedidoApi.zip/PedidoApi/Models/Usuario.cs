﻿using System;
using System.Collections.Generic;

namespace PedidoApi.Models;

public partial class Usuario
{
    public int Idusuario { get; set; }

    public string Nome { get; set; } = null!;

    public string Email { get; set; } = null!;
}
